/*********************************************************
* Javascript implementation of fns for CryptX 4.0 up 	 *
* This Javascript file is exclusively made after 		 *
* long periods of research & developmet by our R & D Team*
* (c) 2006 June Centrum inc Software Solutions		     *
* webpresence @ http://www.geocities.com/mhkonine2/		 *
* e-mail us :midhunhk@gmail.com							 *
**********************************************************/

/* COMMAND LINE FORMAT OF CRYPTX4
CRYPTX4.EXE    <filename>   <ext>  <enc/dec> <fileoutput>   <setfile>    <pword>  <mode>   
  cryptx4.exe  c:\test.xml   xml       E     c:\test.rap    c:\test.set   pass     TXT
  cryptx4.exe  c:\test.rap   rap       D     c:\            c:\test.set   pass	   NIL
*/

/*NOTE FOR DEVELOPERS - EXECUTION OF SCRIPT FUNCTIONS
VB Fn -> filename() -> getfilename() -> [calls addslash() and dosName()]
addSlash() adds a slash to the given string
dosName()  converts given string to 8 chara dos format. Note that the given string is longer than 8 charas
getFileName() gets filename from browse box and checks folder and file anmes for length and converts to appropriate format. These are done using addslash() and dosName()
filename() gets the appropriate filename from getFileName(), checks the extension for compatability and returns the command line name and arguments for external xryptx program.
vb fn runs the cryptx pgm with arguments provided from the fn filename()

NOTE : this script uses RSA Data Security, Inc. MD5 Message-Digest Algorithm or MD5. The code is included in md5.js
*/

var _ex ="";
/* Body of Helper Functions*/ 
function addSlash(string)
{    /* Fn to add slashes to the string that is passed in*/ 
	string+="\\";
	return string;
}
function addSpace(string)
{	/* Fn to add spaces to the string passed in : used to generate the command line parameters*/
	string+=" ";
	return string;
}
function dosName(string)
{   /* Fn to convert a string to dos format. Devel_note : Not 100% efficient*/
	var str1=string,str2,str3,str4,lastpos=0;
	for(var i=0;i<8;i++)	// Test fix to catch multiple spaces 12:11 PM 3/6/06
	{			// Bug Fix 0.78
		/* Loop to get rid of spaces that come in the first 6 chars of folder names. Else Cryptx4 will report invalid no of arguments eg: My Documents should be renamed as MYDOCU~1*/
		if(str1.charAt(i)==" ")
		{
			str3 = str1.substring(lastpos,i);
			lastpos = i+1;
			str4 = str1.substring(lastpos,8);
			str3+=str4;
		}
	}
	if(str3)
		str2 = str3.substring(0,6);
	else
		str2 = string.substring(0,6);
	str2+="~1";
	return str2;
}

   /* Fn to get filename from the Browse txt box and convert it into proper format for working with the Cryptx Dos File*/
function getFileName()
{
	var msg = document.getElementById("source").value; 	// V 1.4 Getting File's Path
	var ch = "\\";										// The Slash \ Escape Character
	var nu = "",n=0,cnt=0;								// Variable initialisation
	var len = msg.length;
	var m = msg.lastIndexOf(ch);
	var isRapFile = false;
	var fileNameWithoutExt = "";

	for(var i=0;i<len;i++)	  						   	// loop to count the no of slashes
	{
		if(msg.charAt(i)==ch)
			cnt++;
	}													// End Loop
if(!len)
{
	alert("No File Name Specified");
	return nu;
}
else	// else id 627JD
{
	nu = msg.substring(0,2);	// Gets the drive letter and colon 	eg: D:
	nu = addSlash(nu);			// add slash	eg: D:\
// Loop to convert folder names to proper format
	while(1)
	{
		i = msg.indexOf(ch,n);
		j = msg.indexOf(ch,i+1);
		if((i==-1)||(j==-1)) 	// No more slashes indicating end of folder names in path. So Get Out of infinite loop?
			break;
		n=j;					// New n for next slash
		var str = msg.substring(i+1,j);
		if(str.length>8)
		{						// Convert folder name to proper format and add slash
			nu += dosName(str);
			nu = addSlash(nu);
		}
		else
		{						// Just append the folder name to the filename string and add a slash
			nu += str;
			nu = addSlash(nu);
		}
	}
// End While Loop
	var dot = msg.lastIndexOf(".");	// Location of dot for extension
	var str2 = msg.substring(m+1,dot);	// Plain Filename - frm last slash to dot
	var hasSpaces = false;
	for(var i=0;i<str2.length;i++)	//	V 3.3 �
	{	if(str2.charAt(i)==' ')		// On first space, get out of the loop!
		{	hasSpaces = true;	break;		}
	}
	var ext = msg.substr(dot);		// Extension

	_ex = msg.substr(dot+1);
	_ex = _ex.toLowerCase();
	if(_ex=="rap")	isRapFile = true;
	if(hasSpaces)	nu+=dosName(str2);
	else			nu+=str2;
	fileNameWithoutExt = nu;
	var outPutFile = fileNameWithoutExt;
	nu+=ext;						// Add Extension to filename
}// End of else id 627JD
	{// block to generate the correct command line params for Cryptx4 32 bit
		nu = addSpace(nu);
		nu+=_ex;
		if(isRapFile)	nu+=" D ";	//	Needs to be decrypted
		else{			nu+=" E ";	//	Needs to be encrypted
			outPutFile += ".rap";	//	output filename
		}
		nu+=outPutFile;
		nu = addSpace(nu);
		fileNameWithoutExt +=".set";
		nu+=fileNameWithoutExt;
	}
	return nu;
}

/* Fn that hands over the filename to VBScript fn*/
function filename()					//JS_Fn id_ios67
{
	var file = getFileName();	// V 2.0
	var filename = "";
if(file)
{	
	var ext = _ex.toLowerCase();
	var len = file.length;
	var processed = false;
	var passFrom = document.form1.pass.value;	//	V 4.2
	if(!passFrom){
		alert("No Password Specified");	return "";
	}
	var passMD5  = hex_md5(passFrom);// V 3.5
	
	/* Extension filter in V 2.0 */
/* Text Mode Extensions */
extTxt = new Array("asp","bat","c","cpp","def","dic","h","htm","ini","inc","inf","js","log","php","rtf","txt","xml");

/* Binary Mode Extensions */
extBin = new Array("exe","bin","zip", "mp2","mp3","mp4","pdf","bmp","doc","xls","wmv","mpg","mpe","jpe","jpg","png","tga","aif","arc","dng","mng","gif","gz","lzh","ppt","pps","pak","psd","tar","rar","7z","wav","wma","swf","wmv");

// Checking extensions for compatability
	for (var i = 0; i < extTxt.length; i++) {
	if (extTxt[i] == ext) { filename = "DATA\\CRYPTX4.EXE "+file+" "+passMD5 +  " TXT"; processed = true; break; }
	}
	for (var i = 0; i < extBin.length; i++) {
	if (extBin[i] == ext) { filename = "DATA\\CRYPTX4.EXE "+file+" "+passMD5 + " BIN"; processed = true; break; }
	}
	if(ext == "rap"){ filename = "DATA\\CRYPTX4.EXE " + file+" "+passMD5 + " NIL";processed = true;}	//	Rap File To be Encrypted
}
if(processed == false)
	alert("This Extension cannot be processed.See the \naccompanying help file for format compatabilities ");
else
//	alert(filename);
	return (filename);
}